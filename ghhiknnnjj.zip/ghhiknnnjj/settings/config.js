import chalk from 'chalk';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);

global.ownerNumber = '6282119690755'
global.ownerName = '6282119690755'
global.owner = ['6282119690755']

//SALURAN
global.idch = '120363418408648758@newsletter'

//RENAME BOT DISINI AJE GAUSAH JAUH²
//WATERMARK
global.footer = 'R I S S X D'
//ID CH
global.idch = '120363418408648758@newsletter'
//SET STICKER
global.packname = '• Bots •'
global.author = 'Rukaa MD'
//SET NAME
global.botName = 'RUKA-MD'
//SET IMAGE
global.image = {
menu: 'https://files.catbox.moe/c13yq7.jpeg',
denied: 'https://files.catbox.moe/vtvr0f.jpeg',
limit: 'https://files.catbox.moe/5vq9xx.jpeg',
reply: 'https://files.catbox.moe/pskakb.jpeg'
}
//SET AUDIO
global.audio = {
menu: 'https://files.catbox.moe/os3gek.mpeg'
}



//SETUP DISCORD ( GAUSAH KALO GAPUNYA )
global.discordToken = ''
global.clientID = '' 
global.guildID = ''





fs.watchFile(__filename, () => {
    fs.unwatchFile(__filename);
    console.log(chalk.redBright(`Update ${__filename}`));
    import(`${import.meta.url}?update=${Date.now()}`)
        .then(() => console.log('Kode diperbarui!'))
        .catch(err => console.error('Gagal memperbarui:', err));
});