import fs from 'fs';
import path from 'path';
import { REST, Routes, SlashCommandBuilder } from 'discord.js';
import chokidar from 'chokidar';
import { pathToFileURL } from 'url';

const commandMap = new Map(); // filePath -> commandName

async function getAllCommandFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = await Promise.all(
    entries.map(entry => {
      const fullPath = path.join(dir, entry.name);
      return entry.isDirectory() ? getAllCommandFiles(fullPath) : fullPath;
    })
  );
  return files.flat().filter(f => f.endsWith('.js'));
}

async function buildCommand(filePath) {
  const modulePath = pathToFileURL(filePath).href + `?t=${Date.now()}`;
  const { default: handler } = await import(modulePath);
  if (!handler || typeof handler.command !== 'string') return null;

  const builder = new SlashCommandBuilder()
    .setName(handler.command)
    .setDescription(handler.description || 'No description');

  if (Array.isArray(handler.options)) {
    for (const opt of handler.options) {
      if (!opt.name || !opt.description) continue;
      switch (opt.type) {
        case 'STRING':
          builder.addStringOption(o => o.setName(opt.name).setDescription(opt.description).setRequired(!!opt.required));
          break;
        case 'INTEGER':
          builder.addIntegerOption(o => o.setName(opt.name).setDescription(opt.description).setRequired(!!opt.required));
          break;
        // Tambah jenis option lain jika perlu
      }
    }
  }

  return { name: handler.command, handler, builder };
}

export async function loadSlashCommands(client, token, clientId, guildId) {
  const commandsDir = path.join(process.cwd(), 'discord', 'commands', 'slash');
  const commandFiles = await getAllCommandFiles(commandsDir);

  const rest = new REST({ version: '10' }).setToken(token);
  const route = guildId
    ? Routes.applicationGuildCommands(clientId, guildId)
    : Routes.applicationCommands(clientId);

  client.slashCommands = new Map();
  const commandsPayload = [];
  const loadedNames = new Set();

  for (const file of commandFiles) {
    const cmd = await buildCommand(file);
    if (!cmd) continue;
    if (loadedNames.has(cmd.name)) {
      console.warn(`⚠️ Duplikat command "${cmd.name}" dilewati`);
      continue;
    }
    loadedNames.add(cmd.name);
    commandsPayload.push(cmd.builder.toJSON());
    client.slashCommands.set(cmd.name, cmd.handler);
    commandMap.set(file, cmd.name);
    console.log(`✅ Loaded: ${cmd.name}`);
  }

  try {
    const existing = await rest.get(route);
    for (const cmd of existing) {
      if (!loadedNames.has(cmd.name)) {
        console.log(`🗑 Menghapus command lama dari Discord: ${cmd.name}`);
        await rest.delete(`${route}/${cmd.id}`);
      }
    }

    await rest.put(route, { body: commandsPayload });
    console.log('✅ Semua slash command didaftarkan ulang');
  } catch (err) {
    console.error('❌ Gagal daftarkan command:', err);
  }

  client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;
    const handler = client.slashCommands.get(interaction.commandName);
    if (!handler) return;
    try {
      await handler(interaction);
    } catch (err) {
      console.error(err);
      const r = { content: '❌ Gagal mengeksekusi perintah.', ephemeral: true };
      interaction.replied || interaction.deferred
        ? interaction.followUp(r)
        : interaction.reply(r);
    }
  });

  // Hot reload pakai chokidar
  chokidar.watch(commandsDir, { ignoreInitial: true })
    .on('add', async file => {
      console.log(`➕ File baru: ${file}`);
      const cmd = await buildCommand(file);
      if (cmd && !client.slashCommands.has(cmd.name)) {
        client.slashCommands.set(cmd.name, cmd.handler);
        commandMap.set(file, cmd.name);
        await loadSlashCommands(client, token, clientId, guildId);
      }
    })
    .on('change', async file => {
      console.log(`♻️ File berubah: ${file}`);
      const oldName = commandMap.get(file);
      const cmd = await buildCommand(file);
      if (cmd) {
        if (oldName) client.slashCommands.delete(oldName);
        client.slashCommands.set(cmd.name, cmd.handler);
        commandMap.set(file, cmd.name);
        await loadSlashCommands(client, token, clientId, guildId);
      }
    })
    .on('unlink', async file => {
      console.log(`❌ File dihapus: ${file}`);
      const oldName = commandMap.get(file);
      if (oldName) {
        client.slashCommands.delete(oldName);
        commandMap.delete(file);
        await loadSlashCommands(client, token, clientId, guildId);
      }
    });
}
