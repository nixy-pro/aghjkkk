import { PermissionFlagsBits } from 'discord.js';

let handler = async (m) => {
  if (!m.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
    return m.reply({ content: '❌ Kamu tidak punya izin Manage Messages.', ephemeral: true });
  }

  const jumlah = m.options.getInteger('jumlah');
  if (!jumlah || jumlah < 1 || jumlah > 100) {
    return m.reply({ content: '❗ Jumlah harus antara 1 sampai 100.', ephemeral: true });
  }

  try {
    const messages = await m.channel.messages.fetch({ limit: jumlah });
    await m.channel.bulkDelete(messages, true);

    return m.reply({ content: `✅ Berhasil hapus ${messages.size} pesan.`, ephemeral: true });
  } catch (error) {
    console.error('Error purge:', error);
    return m.reply({ content: '❌ Gagal menghapus pesan.', ephemeral: true });
  }
};

handler.command = 'purge';
handler.description = 'Hapus sejumlah pesan di channel ini (max 100)';
handler.options = [
  {
    name: 'jumlah',
    type: 'INTEGER',
    description: 'Jumlah pesan yang ingin dihapus (max 100)',
    required: true
  }
];

export default handler;
