import fs from 'fs';
import path from 'path';

export async function loadPrefixCommands(client) {
  client.prefixCommands = new Map();
  const commandsPath = path.join(process.cwd(), 'discord', 'commands', 'prefix');
  const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

  for (const file of files) {
    const { default: handler } = await import(path.join(commandsPath, file));
    if (handler.command && typeof handler === 'function') {
      client.prefixCommands.set(handler.command, handler);
      console.log(`Loaded prefix command: ${handler.command}`);
    }
  }

  client.on('messageCreate', async message => {
    if (message.author.bot) return;
    const prefix = '!';
    if (!message.content.startsWith(prefix)) return;

    const parts = message.content.slice(prefix.length).trim().split(/\s+/);
    const cmd = parts.shift().toLowerCase();
    const args = parts;

    const handler = client.prefixCommands.get(cmd);
    if (!handler) return;
    try {
      await handler(message, { args, client });
    } catch (e) {
      console.error('Prefix command error:', e);
      await message.reply('Error executing prefix command.');
    }
  });
}
