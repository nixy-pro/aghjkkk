import fs from 'fs';
import path from 'path';

export async function loadDiscordCommands(client) {
  const commandsPath = path.join(process.cwd(), './discord/commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = await import(filePath);
    
    if (command.default?.name && command.default?.execute) {
      client.commands.set(command.default.name, command.default);
      console.log(`Command loaded: ${command.default.name}`);
    }
  }

  // Event handler pesan masuk
  client.on('messageCreate', async message => {
    if (message.author.bot) return;

    const prefix = '!';
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName); // Gunakan yang sudah di-cache
    if (!command) return;

    try {
      await command.execute(message, args, client);
    } catch (err) {
      console.error('Error executing command:', err);
      await message.reply('There was an error executing that command.');
    }
  });
}
